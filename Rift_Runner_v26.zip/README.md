# Rift Runner v26
Static single-file game: `index.html` (Three.js r128 loads from CDN). Deploy: GitHub Pages (Settings > Pages > main / root), Vercel or Netlify (drag the folder, no build step).

## v26 changes
- Camera keeps the hovercraft inside a safe zone on any aspect ratio (looks lower only as much as needed).
- Menu/UI auto-fits: shrinks to fit short or small windows, re-checked every 1.2 s and on resize/rotation.
- PC controls: ← → / A D lanes, ↑ / W jump, ↓ / S slide, Space dash, N nitro, P or Esc pause, F fullscreen, M mute, F2 FPS panel. Gamepads: X dash, Y nitro, Start pause.
